/*
 * student name: Nadav Schweitzer & Ben Shimoni
 * exercise name: ex4
 * file description: Recv class
 */
#include "Recv.h"

//constructor
Recv::Recv()
{
	this->sock = 0;
}
Recv::~Recv()
{

}
