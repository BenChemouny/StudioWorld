#include "Recv.h"

Recv::Recv()
{
	this->sock = 0;
}
Recv::~Recv()
{

}
