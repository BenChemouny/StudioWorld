/****************************************
* Student Name: Nadav and Ben            *
* Exercise Name:  EX-4              *
* File description:  ConCt.cpp              *
****************************************/
#include "ConCt.h"

ConCt::ConCt() {
}
ConCt::~ConCt() {
	// TODO Auto-generated destructor stub
}

